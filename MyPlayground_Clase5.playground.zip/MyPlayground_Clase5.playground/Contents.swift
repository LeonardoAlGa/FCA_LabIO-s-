import SwiftUI

var greeting = "Hello, playground"

func priceFor(item unitPrice: Double, _ ammount: Double) -> Double {
    let beforeIvaPrice = unitPrice * ammount
    let iva = beforeIvaPrice * 0.16
    return beforeIvaPrice + iva
}

// Falta codigo
var r = priceFor (item: 1500, 2)
print (r)

func check(_ age: Int, _ active: Bool, _ verified: Bool) -> Bool {
    if age >= 18 && active && verified{
        return true
    }else{
        return false
    }
}

func checkGood (_ age: Int, _ active: Bool,_ verified: Bool)->Bool{
    guard age >= 18 else{
        return false
    }
    
    return active && verified
    
}

func process (_ meals: [Bool])-> String{
    
    var x = 0
    
    for meal in meals{
        if meal{
            x+=1
        }
    }
    
    if x == meals.count{
        return "Good"
    }
    
    if x >= meals.count / 2 {
        return "Reguler"
    }
    
    return "Bad"
}

func calculateCompletedMeals (for meals: [Bool])-> String{
    
    var completedMeals = meals.filter {$0}.count
    
    if completedMeals == meals.count{
        return "Good"
    } else if completedMeals >= meals.count / 2 {
        return "Regular"
    } else {
        return "Bad"
    }
    
}


// MARK: Funciones pequeñas, early return y guard

func canEnter (age: Int, hasTicket: Bool) -> Bool {
    if age >= 18{
        if hasTicket{
            return true
        }else{
            return false
        }
    }else{
        return false
    }
}

func canEnterGood (age: Int, hasTicket: Bool) -> Bool {
    guard age >= 18 else {return false}
    
    guard hasTicket else{return false}
    
    return true
    
}

func printUserName(userName: String?){
    if let userName = userName{
        if !userName.isEmpty{
            print ("Hola, \(userName)")
        }
    }
}

//Pendiente
func printUserNameGood(userName: String?){
    if let userName = userName{
        if !userName.isEmpty{
            print ("Hola, \(userName)")
        }
    }
}

func prepareOrder(
    userId: String?,
    productId: String?,
    quantity: Int,
    isActive: Bool
)-> String{
    
    guard let userId else { return "User not found" }
    
    guard let productId else { return "Product not found"}
    
    guard isActive else { return "User is not active"}
    
    guard quantity > 0 else { return "Invalid quantity"}
    
    return"Order \(productId) for user \(userId), quantity: \(quantity)"
    
}

// MARK Duplicación y reutilización

struct Constants {
    let tax = 0.16
}

func getPrice(){
    let breakfastPrice = 85.0
    let lunchPrice = 120.0
    let dinnerPrice = 150.0
    
    
    let breackfastWithTax = breakfastPrice + breakfastPrice * 0.16
    let lunchWithTax = lunchPrice + lunchPrice * 0.16
    let dinnerWithTax = dinnerPrice + dinnerPrice * 0.16
    
    print ("Breakfast: $\(breackfastWithTax)")
    print ("Lunch: $\(lunchWithTax)")
    print ("Dinner: $\(dinnerWithTax)")
}

func calculatePriceWithTax(for price: Double) -> Double{
    price + price * Constants().tax
}

func showPriceWithTax(_ price: Double, for meal: String){
    print ("\(meal): $\(price)")
}

func getPriceGood(){
    let breakfastPrice = 85.0
    let lunchPrice = 120.0
    let dinnerPrice = 150.0
    
    showPriceWithTax(calculatePriceWithTax(for: breakfastPrice), for: "Breakfast")
    showPriceWithTax(calculatePriceWithTax(for: lunchPrice), for: "Lunch")
    showPriceWithTax(calculatePriceWithTax(for: dinnerPrice), for: "Dinner")
    
}











