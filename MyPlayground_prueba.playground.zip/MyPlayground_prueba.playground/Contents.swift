import UIKit
/*
var greeting = "Hello, playground"

print("Hola todos")

greeting = "Hola otra vez"

let movies: [String] = ["Dune", "Arrival", "Interestellar"]

for index in 0..<movies.count {
    guard movies[index] == "Dune" else{
        continue
    }
    if movies[index] == "Dune"{
        print (index)
    } else if movies [index] == "Arrival"{
        
    }
        
}

func returnName(function: @escaping (Int) -> (Bool)) -> String {
    function(2)
    print("Estoy revisando")
    return movies [0]
}

returnName{ index in
    print("escaping func")
    return (false)
}

enum iosclass: Int {
    case profe = 1
    case alumno
    case encargado
    case errorType
}

let classes = iosclass.alumno

switch classes{
    case .profe:
        print ("")
    case .alumno:
        print ("")
    case .encargado:
        print ("")
    case .errorType:
        print("")
    
}
class Proyect{
    let test: Int
    init (test: Int){
        self.test = test }
}

struct ProyectStruct{
    let test: Int
    let string : String
    var x : Bool
    
    init(test: Int, string: String, x : Bool){
        
        self.test = test
        self.string = string
        self.x = x
    }
    
    init(test: Int, string: String){
        self.test = test
        self.string = string
        self.x=true
    }
}

let new = Proyect (test : 1)
//let newStruct = ProyectStruct(test: <#T##Int#>, string: <#T##String#>, x: Bool)

protocol Test{
    var x: Int {get}
    var y: Int {get set}
    var name: String {get}
}

class NewClass: Test{
    let x: Int
    var y: Int
    let name: String
    private let secret = "secret"
        
        init (x: Int, y: Int, name: String){
            self.x=x
            self.y=y
            self .name = name
        }
    }

class NewClassTwo: Test{
    
    let x:Int
    var y: Int
    let name: String
    
    
    
    init (x: Int, y: Int, name: String){
        self.x=x
        self.y=y
        self .name = name
    }
}

var testClasses: Test
testClasses = NewClass(x:1, y:2, name: "")
testClasses = NewClassTwo(x:1, y:2, name: "")

let newClass = NewClassTwo(x:1, y:2, name: "name")

extension NewClassTwo{
    func getSum(){
        print (x+y)
    }
//                  Esta <T> es un genérico, es como un comodín que cambia depende del tipo de dato que recibe
    // el T? significa que puede ser opcional, la letra puede ser cualquiera, lo que especifica que es genérico son las "<>" y los "[]"
    func firstElement<T> (from values: [T]) -> T?{
        guard let first = values.first else {return nil}
        // Nil es vacío, regresa lo mismo que null
        return first
    }
    
    func optionals(){
        var x: Int?
        if x == 1000 {
            return
        }
        let y = x!
        
        y
        
    }
        // EL throws indica que tenemos que checar lo que vamos a estipular
    func validate(movie: String) throws{
        if movie == ""{
            throw MovieError.internetError
        }
        let newMovie = movie.capitalized
        print(newMovie)
        
    }
    func getMovieTitle(){
        do{
            try validate(movie:"")
        }catch{
            print(error.localizedDescription)
        }
    }
    
}

enum MovieError: Error{
    case internetError
} */

import Foundation

enum MovieError: Error{
    case internetError
}

func loadMovie(error: Bool) async throws -> String{
    print("Movie")
    sleep(3)
    if error {
        throw MovieError.internetError
    }
    return "Dune"
}
//Asincrono es que va a tardar más el tiempo en ejecución, otros pueden estar haciendo otra cosa y después el proceso puede regresar
print ("Start")
Task{
    do{
        let x = try await loadMovie(error:true)
        print(x)
    } catch{
        print(error.localizedDescription)
    }
    
    
}
print("End")



